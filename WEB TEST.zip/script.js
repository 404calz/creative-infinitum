// ==============================
// DATA PRODUK
// ==============================
let products = JSON.parse(localStorage.getItem("products")) || [
    {
        id: 1,
        name: "Lampu Hias Kayu",
        desc: "Dekorasi aesthetic berbahan kayu premium.",
        price: 125000,
        img: "https://i.imgur.com/aV0P4VK.jpeg"
    },
    {
        id: 2,
        name: "Notebook Handmade",
        desc: "Buku catatan buatan tangan, cocok untuk kado.",
        price: 79000,
        img: "https://i.imgur.com/8xKPk0m.jpeg"
    },
    {
        id: 3,
        name: "Tas Anyaman",
        desc: "Tas kreatif berbahan alami, ramah lingkungan.",
        price: 150000,
        img: "https://i.imgur.com/JXmdEne.jpeg"
    }
];

let cart = [];



// ==============================
// RENDER PRODUK DI HOMEPAGE
// ==============================
function loadProducts(filtered = null) {
    const list = filtered || products;

    const container = document.getElementById("product-list");
    if (!container) return;

    container.innerHTML = "";

    list.forEach(product => {
        container.innerHTML += `
            <div class="product-card">
                <img src="${product.img}">
                <div class="info">
                    <h3>${product.name}</h3>
                    <p>${product.desc}</p>
                    <div class="price">Rp ${product.price.toLocaleString()}</div>

                    <a href="product.html?id=${product.id}">
                        <button class="btn">Lihat Detail</button>
                    </a>

                    <button class="btn" onclick="addToCart(${product.id})">Tambah ke Keranjang</button>
                </div>
            </div>
        `;
    });
}



// ==============================
// PENCARIAN PRODUK
// ==============================
function searchProduct() {
    const q = document.getElementById("search-input").value.toLowerCase();
    const filtered = products.filter(p => p.name.toLowerCase().includes(q));
    loadProducts(filtered);
}



// ==============================
// DETAIL PRODUK
// ==============================
function renderProductDetail(id) {
    const item = products.find(p => p.id == id);
    const box = document.getElementById("product-detail");
    if (!box) return;

    box.innerHTML = `
        <img src="${item.img}">
        <div>
            <h2>${item.name}</h2>
            <p>${item.desc}</p>
            <h3>Rp ${item.price.toLocaleString()}</h3><br>
            <button class="btn" onclick="addToCart(${item.id})">Tambah ke Keranjang</button>
        </div>
    `;
}


// ==============================
// KERANJANG
// ==============================
function addToCart(id) {
    const item = products.find(p => p.id === id);
    cart.push(item);
    alert("Produk ditambahkan ke keranjang.");
}



// ==============================
// LOGIN & REGISTER
// ==============================
let users = JSON.parse(localStorage.getItem("users")) || [];

function registerUser() {
    const name = document.getElementById("reg-name").value;
    const email = document.getElementById("reg-email").value;
    const pass = document.getElementById("reg-pass").value;

    users.push({ name, email, pass });
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registrasi berhasil!");
    window.location = "login.html";
}

function loginUser() {
    const email = document.getElementById("login-email").value;
    const pass = document.getElementById("login-pass").value;

    const found = users.find(u => u.email === email && u.pass === pass);

    if (!found) return alert("Email atau password salah.");

    alert("Login berhasil.");
    window.location = "index.html";
}



// ==============================
// ADMIN: TAMBAH PRODUK
// ==============================
function addProduct() {
    const name = document.getElementById("p-name").value;
    const desc = document.getElementById("p-desc").value;
    const price = Number(document.getElementById("p-price").value);
    const img = document.getElementById("p-img").value;

    const newProduct = {
        id: Date.now(),
        name,
        desc,
        price,
        img
    };

    products.push(newProduct);
    localStorage.setItem("products", JSON.stringify(products));

    alert("Produk berhasil ditambah.");

    loadAdminProducts();
}

function loadAdminProducts() {
    const box = document.getElementById("admin-product-list");
    if (!box) return;

    box.innerHTML = "";

    products.forEach(p => {
        box.innerHTML += `
            <div style="margin:10px;padding:10px;background:#f9f9f9;border-radius:8px">
                <b>${p.name}</b> — Rp ${p.price.toLocaleString()}
            </div>
        `;
    });
}

loadAdminProducts();
loadProducts();
// ==============================
// RENDER KERANJANG DI cart.html
// ==============================
function renderCartPage() {
    const container = document.getElementById("cart-container");
    if (!container) return;

    container.innerHTML = "";

    cart.forEach((item, index) => {
        container.innerHTML += `
            <div class="cart-item">
                <img src="${item.img}">
                <div class="cart-info">
                    <h3>${item.name}</h3>
                    <p>Rp ${item.price.toLocaleString()}</p>
                </div>

                <button class="btn remove-btn" onclick="removeFromCart(${index})">
                    Hapus
                </button>
            </div>
        `;
    });

    updateCartTotal();
}

// Hapus item dari keranjang (khusus halaman cart)
function removeFromCart(index) {
    cart.splice(index, 1);
    renderCartPage();
}

// Hitung total harga
function updateCartTotal() {
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    const target = document.getElementById("cart-total");
    if (target) target.innerText = "Rp " + total.toLocaleString();
}

// Checkout
function checkoutCart() {
    if (cart.length === 0) return alert("Keranjang kosong.");

    alert("Checkout berhasil (simulasi).");
    cart = [];
    renderCartPage();
}
